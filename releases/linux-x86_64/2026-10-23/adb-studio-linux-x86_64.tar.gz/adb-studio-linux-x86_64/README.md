# ADB 工作台

进入解压目录运行 `./adb-studio`，打开 http://127.0.0.1:17841 。

安装、自启、环境变量与迁移见 [部署说明](docs/deployment.md)。

[纯视觉识别](docs/vision-recognition.md) · [投屏与操作](docs/realtime-screen.md) · [工作流接口](docs/workflows.md)
